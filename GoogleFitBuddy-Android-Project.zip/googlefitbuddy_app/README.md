# GoogleFitBuddy Android App

This is an Android WebView app wrapping the existing GoogleFitBuddy frontend. The Gemini API key stays on the Flask backend; the APK never contains the key.

## 1. Deploy the backend
Use the existing `app(1).py` and `requirements(1).txt`. Set `GEMINI_API_KEY` on the server and run Flask behind HTTPS.

## 2. Set the backend URL
Edit `app/src/main/java/com/googlefitbuddy/app/MainActivity.java` and replace `API_URL` with:
`https://YOUR-DOMAIN/api/generate-plan`

## 3. Build
Open this folder in Android Studio, let Gradle sync, then choose **Build > Build APK(s)**.

The generated APK will be under `app/build/outputs/apk/debug/` for a debug build.
