const btn = document.getElementById('genBtn');
const statusLine = document.getElementById('statusLine');
const skeleton = document.getElementById('skeleton');
const results = document.getElementById('results');

btn.addEventListener('click', generatePlan);

function esc(s) {
  const d = document.createElement('div');
  d.textContent = s == null ? '' : String(s);
  return d.innerHTML;
}

async function generatePlan() {
  const goal = document.getElementById('goal').value;
  const level = document.getElementById('level').value;
  const equipment = document.getElementById('equipment').value;
  const diet = document.getElementById('diet').value;

  statusLine.textContent = '';
  statusLine.classList.remove('error');
  results.classList.remove('show');
  skeleton.classList.add('show');
  btn.disabled = true;
  btn.textContent = 'BUILDING…';

  try {
    const payload = { goal, level, equipment, diet };
    let data;

    if (window.Android && typeof window.Android.generatePlan === 'function') {
      data = JSON.parse(await window.Android.generatePlan(JSON.stringify(payload)));
    } else {
      const res = await fetch('/api/generate-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Something went wrong.');
      }
    }

    if (data.error) throw new Error(data.error);
    renderPlan(data);
    statusLine.textContent = 'Plan ready.';
  } catch (err) {
    statusLine.textContent = err.message || 'Couldn\u2019t generate a plan. Try again.';
    statusLine.classList.add('error');
  } finally {
    skeleton.classList.remove('show');
    btn.disabled = false;
    btn.textContent = 'GENERATE PLAN';
  }
}

function renderPlan(data) {
  const s = data.user_summary || {};
  document.getElementById('macros').innerHTML = [
    ['CALORIES / DAY', s.recommended_daily_calories],
    ['PROTEIN (G)', s.target_protein_g],
    ['CARBS (G)', s.target_carbs_g],
    ['FATS (G)', s.target_fats_g]
  ].map(([lbl, val]) => `
    <div class="macro-cell">
      <div class="num">${esc(val)}</div>
      <div class="lbl">${esc(lbl)}</div>
    </div>
  `).join('');

  const days = data.weekly_schedule || [];
  document.getElementById('dayTabs').innerHTML = days.map((d, i) =>
    `<button class="day-tab${i === 0 ? ' active' : ''}" data-i="${i}">${esc(d.day || 'Day ' + (i + 1))}</button>`
  ).join('');

  document.getElementById('dayPanels').innerHTML = days.map((d, i) => {
    const w = d.workout || {};
    const warm = (w.warmup || []).map(x => `<li>${esc(x)}</li>`).join('');
    const cool = (w.cooldown || []).map(x => `<li>${esc(x)}</li>`).join('');
    const rows = (w.exercises || []).map(ex => `
      <tr>
        <td class="ex-name">${esc(ex.name)}<div class="ex-notes">${esc(ex.notes || '')}</div></td>
        <td class="num-col">${esc(ex.sets)}</td>
        <td class="num-col">${esc(ex.reps)}</td>
        <td class="num-col">${esc(ex.rest_seconds)}s</td>
      </tr>
    `).join('');
    const m = d.meals || {};
    const meals = ['breakfast', 'lunch', 'dinner', 'snack'].map(k => `
      <div class="meal-cell">
        <div class="mlbl">${k}</div>
        <div class="mtext">${esc(m[k] || '—')}</div>
      </div>
    `).join('');

    return `
      <div class="day-panel${i === 0 ? ' active' : ''}" data-i="${i}">
        <p class="focus-tag">FOCUS — ${esc(d.focus || '')}</p>

        <h3 class="section-h">Warm-up</h3>
        <ul class="warmup-list">${warm}</ul>

        <h3 class="section-h">Exercises</h3>
        <table class="ex-table">
          <thead><tr><th>Movement</th><th>Sets</th><th>Reps</th><th>Rest</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>

        <h3 class="section-h">Cool-down</h3>
        <ul class="cooldown-list">${cool}</ul>

        <h3 class="section-h">Meals</h3>
        <div class="meals-grid">${meals}</div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('.day-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.day-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.day-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.querySelector(`.day-panel[data-i="${tab.dataset.i}"]`).classList.add('active');
    });
  });

  const g = data.grocery_list || {};
  const groups = [
    ['Proteins', g.proteins], ['Carbs & grains', g.carbs_and_grains],
    ['Produce', g.produce], ['Pantry', g.pantry]
  ];
  document.getElementById('groceryGrid').innerHTML = groups.map(([lbl, items]) => `
    <div class="grocery-col">
      <div class="glbl">${esc(lbl)}</div>
      <ul>${(items || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul>
    </div>
  `).join('');

  results.classList.add('show');
}
